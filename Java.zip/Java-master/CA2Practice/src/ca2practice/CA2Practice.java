
package ca2practice;

/**
 *
 * @author deanc
 */
public class CA2Practice {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
