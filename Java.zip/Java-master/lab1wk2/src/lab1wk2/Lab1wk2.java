package lab1wk2;

import java.util.Scanner;

/**
 *
 * @author X00147130
 */
public class Lab1wk2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Scanner
        Scanner sc = new Scanner(System.in);

        //Variables
        double[][] results = new double[5][4];
        double total = 0;
        double average = 0;
        double overallAverage = 0;
        int higher = 0;
        double difference = 0;
        double tempVariable = 0;
        int lower = 0;
        double overallTotal = 0;

        //algorithm
        for (int i = 0; i < results.length; i++) {
            for (int j = 0; j < results[0].length; j++) {
                System.out.printf("Please enter the grades for student %d ", (i + 1));
                tempVariable = sc.nextDouble();
                while (tempVariable > 100 || tempVariable < 0) {
                    System.out.println("Error not a valid grade, Please re-enter:");
                    tempVariable = sc.nextDouble();
                }
                results[i][j] = tempVariable;
               
            }
       }

        for (int i = 0; i < results.length; i++) {
           total=0;
            for (int j = 0; j < results[0].length; j++) {
                total += results[i][j];
                overallTotal += results[i][j];
            }
        
            average+=total;
            average /= results[0].length;
            System.out.println("Your average is "+average);
            overallAverage+=overallTotal;
       
            
             
             
            if (average >= overallAverage) {
                higher++;
                System.out.println("Congratulations Student your grade was above average");
            } else {
                lower++;
                System.out.println("Student your grade was below average");
            }
            System.out.println("The number of students equal or above the average was " + higher);

        }
        overallAverage /= results.length;
         System.out.println("The overall average is "+overallAverage);
    }
}
