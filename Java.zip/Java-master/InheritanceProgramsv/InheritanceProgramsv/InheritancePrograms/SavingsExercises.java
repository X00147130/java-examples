/**
 * @(#)SavingsExercises.java
 *
 *
 * @author 
 * @version 1.00 2009/3/31
 */


public class SavingsExercises {

   
      public static void main(String args[])
      {
          SavingsAccount s = new SavingsAccount(10,100);        // 10%
          s.addInterest();
          s.print();
          s.withdraw(50);
          s.print();
          System.out.println("\n\n\n New Object");
          CurrentAccount c = new CurrentAccount(1500);
          c.deposit(400);
          c.print();
          c.deposit(600);
          c.print();
      }
}