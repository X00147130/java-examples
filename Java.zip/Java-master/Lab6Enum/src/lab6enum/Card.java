package lab6enum;

/**
 *
 * @author x00147130
 */
public class Card {
     public enum Rank{
        TWO,THREE,FOUR,FIVE,SIX,SEVEN,EIGHT,NINE,TEN,JACK,QUEEN,KING,ACE
        }
 public enum Suit{
     SPADES,HEARTS,DIAMONDS,CLUBS
 }
public Rank rank;  
public Suit suit;

    public Card(Rank rank, Suit suit) {
        this.rank = rank;
        this.suit = suit;
    }

    public Rank getRank() {
        return rank;
    }

    public Suit getSuit() {
        return suit;
    }
    
    

    @Override
    public String toString() {
        return "rank:" + rank + "  suit:" + suit;
        
        
    }


}
