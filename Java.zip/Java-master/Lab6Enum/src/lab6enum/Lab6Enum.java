package lab6enum;

/**
 *
 * @author x00147130
 */
public class Lab6Enum {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Enum
    }
    
}
