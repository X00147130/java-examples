package lab6enum;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author x00147130
 */
public class Deck {
public static List <Card> deck = new ArrayList<>();

public List <Card> createDeck(){
    Card c = new Card(List.of(Card.rank,Card.suit));
    return deck .add(c);
    
}


}
