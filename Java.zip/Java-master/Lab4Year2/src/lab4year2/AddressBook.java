package lab4year2;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author X00147130
 */
public class AddressBook {

    //Scanner
    Scanner sc = new Scanner(System.in);

    // Variables + ArrayList
    private String owner;
    private static int totContacts;
    private ArrayList <Contact> contacts = new ArrayList<>();
    private int maletotContacts;
    Random rand = new Random();

    //member inner class
    public class Contact {

        private String name;
        private char gender;
        private String mobile;

        //Constructor
        public Contact(String nam, char gend, String mob) {
            this.name = nam;
            this.gender = gend;
            this.mobile = mob;
        }

    }

    //Constructor
    public AddressBook(String own) {
        this.owner = own;

    }

    //method
    public void fillList() {
        int numContacts = rand.nextInt();
        for (int i = 0; i < contacts.size(); i++) {
            System.out.println("Please enter Contact name: ");
            String name = sc.nextLine();
            System.out.println("Please enter mobile number: ");
            String mobile = sc.nextLine();
            System.out.println("Please enter gender: ");
            String sex = sc.nextLine();
            char gender = sex.charAt(0);
           
            contacts.add(new Contact(name,gender,mobile));
            totContacts++;
     }
    }
    
    //getter
    public String getOwner() {
        return owner;
    }
    
    //print method
  
    public void print(){
        System.out.println("Address Book belongs to: "+getOwner());
        contacts.forEach(contacts->{
             System.out.println(contacts.name+","+contacts.mobile+","+contacts.gender);
             });
    }
    
    public int getMaleContacts(){
      contacts.forEach(contacts->{
       if(contacts.gender=='m'||contacts.gender=='M'){
          maletotContacts++;
      }
    });
      return maletotContacts;
    }

    public static int totContacts(){
        return totContacts;
    }
}
