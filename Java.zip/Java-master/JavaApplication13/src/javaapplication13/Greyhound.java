
package javaapplication13;

/**
 *
 * @author deanc
 */
public class Greyhound extends Animals {
    
    private String name;
    private int age;
    private String father;
    private String mother;
    private int numOfRaces;
    private int numOfWins;
    boolean results = new boolean[numOfRaces];
}
