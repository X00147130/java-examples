
package javaapplication13;
//imports
import java.util.Scanner;
/**
 *
 * @author deanc
 */
public class JavaApplication13 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Scanner
        Scanner sc=new Scanner (System.in);
        
    }
    
}
