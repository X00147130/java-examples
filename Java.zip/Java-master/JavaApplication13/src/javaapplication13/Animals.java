package javaapplication13;

/**
 *
 * @author deanc
 */
public abstract class Animals {
    //Variables
    public abstract int id ();
    public abstract String type ();
    
    //Constructors
    public Animals(int uniqueID, String animalType){
        uniqueID=id ();
        animalType=type ();
    }
    
    //Print statements
    public void displayDetails () {
        System.out.println("Animal:");
        System.out.println("    id: "+id ());
        System.out.println("    type:"+type ());
        
}
}
